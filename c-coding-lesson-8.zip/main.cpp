//String concatenation, length/size, access
/*#include <iostream>
#include <string>
int main()
{
    std::string numOne="20";
    std::string numTwo="23";
    std::string numThree=numOne+numTwo;
    std::cout<<numThree;
    return 0;
}*/
/*#include <iostream>
int main()
{
    int x,y,z;
    x=10;
    y=20;
    z=x+y;
    std::cout<<z;
    return 0;
}*/
/*#include <iostream>
#include <string>
int main()
{
    std::string alphabets="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    std::cout<<"The length of alphabets are "<<alphabets.length();
    return 0;
}
#include <iostream>
#include <string>
int main()
{
    std::string alphabets="ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    std::cout<<"The length of alphabets are "<<alphabets.size();
    return 0;
}*/
/*#include <iostream>
#include <string>
int main()
{
    std::string word="king";
    word[0]='w';
    std::cout<<word;
    return 0;
}*/
#include <iostream>
#include <string>
int main()
{
    std::string fullName;
    std::cout<<"Type your fullName:";
    getline(std::cin,fullName);
    std::cout<<"My fullName is "<<fullName;
    return 0;
}












