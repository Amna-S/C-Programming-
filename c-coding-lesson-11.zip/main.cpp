//if//
//else//
//else if //
/*#include <iostream>
int main()
{
    int time=20;
    if(time<16)
    {
    std::cout<<"Good morning";
    }
    else if(time < 19)
    {
        std::cout<<"Good afternoon";
    }
    else 
    {
        std::cout<<"Good evening";
    }
    return 0;
}*/
//Switch statement:
#include <iostream>
int main()
{
    int day=5;
    switch (day)
    {
        case 1:
        std::cout<<"Monday";
        break;
        case 2:
        std::cout<<"Tuesday";
        break;
        case 3:
        std::cout<<"Wednesday";
        break;
        case 4:
        std::cout<<"Thursday";
        break;
        case 5:
        std::cout<<"Friday";
        break;
        case 6:
        std::cout<<"Saturday";
        break;
        case 7:
        std::cout<<"Sunday";
        break;
    }
    return 0;
}














