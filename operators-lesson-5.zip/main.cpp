/*#include <iostream>
int main()
{
    int x=5;
    x+=3;
    std::cout<<x;
    return 0;
}*/
#include <iostream>
int main()
{
    int x=50;
    x<<=3; 
    std::cout<<x;
    return 0;
}
