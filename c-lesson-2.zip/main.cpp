/*#include <iostream>
int main()
{
    int myNum; //declaration 
    myNum=50; //assignment
    std::cout<<myNum;
    return 0;
}
*/
/*#include <iostream>
int main() 
{
    int yourAge=11;
    yourAge=12;
    std::cout<<yourAge;
    return 0;
}*/
/*#include <iostream>
int main()
{
    int myheight=5;
    std::cout<<"I have "<<myheight<<" height";
    return 0;
}*/
#include <iostream>
/*int main()
{
    double myheight=5.5;
    std::cout<<"I have "<<myheight<<" height";
    return 0;
}*/

/*#include <iostream>
int main()
{
    bool greeting=false;
    std::cout<<"Today is tuesday and this is "<<greeting;   
    return 0;
}*/

}












