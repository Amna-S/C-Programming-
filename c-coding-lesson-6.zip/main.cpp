/*#include <iostream>
int main ()
{
    int x=9;
    int y=8;
    std::cout<<(x==y);
    return 0;
}
#include <iostream>
int main ()
{
    int x=9;
    int y=8;
    std::cout<<(x!=y);
    return 0;
}
#include <iostream>
int main ()
{
    int x=9;
    int y=8;
    std::cout<<(x>y);
    return 0;
}
#include <iostream>
int main ()
{
    int x=9;
    int y=8;
    std::cout<<(x<y);
    return 0;
}
#include <iostream>
int main ()
{
    int x=9;
    int y=8;
    std::cout<<(x>=y);
    return 0;
}
#include <iostream>
int main ()
{
    int x=9;
    int y=8;
    std::cout<<(x<=y);
    return 0;
}*/

//Logical operators:
#include <iostream>
int main ()
{
    int x=9;
    int y=8;
    std::cout<<(!(x>y&&x<y));
    return 0;
}













