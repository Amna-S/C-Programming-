/*#include <iostream>
int main()
{
    int vowels=6;
    switch(vowels){
        case 1:
        std::cout<<"a";
        break;
        case 2:
        std::cout<<"e";
        break;
        case 3:
        std::cout<<"i";
        break;
        case 4:
        std::cout<<"o";
        break;
        case 5:
        std::cout<<"u";
        break;
        default:
        std::cout<<"Nothing beyond these 5 vowels";
    }
    return 0;
}
#include <iostream>
int main()
{
    int num;
    int diff;
    std::cout<<"Enter a number: ";
    std::cin>>num;
    while(num>=0){
        diff -= num;
        num--;
        std::cout<<"Enter a number:";
        std::cin>>num;
    }
    std::cout<<"The diff is "<<diff;
    return 0;
}*/

























