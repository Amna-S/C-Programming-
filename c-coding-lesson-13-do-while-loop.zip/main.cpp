/*#include <iostream>
int main()
{
    int x;
    for(x=1;x<65;x*=2)
    {
    std::cout<<x<<" ";
    }
    return 0;
}*/
