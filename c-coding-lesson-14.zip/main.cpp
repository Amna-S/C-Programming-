#include <iostream>
int main()
{
    for(int i=1;i<=2;++i)
    {
        std::cout<<"Outer: "<<i<<"\n";
       for(int j=1; j<=3;++j)
       {
           std::cout<<"Inner: "<<j<<"\n";       
       }
    }
    return 0;
}