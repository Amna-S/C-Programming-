#include <iostream>
int main()
{
    const int minutesPerHour=60;
    minutesPerHour=90;
    const double PI=3.14;
    std::cout<<minutesPerHour<<"\n"<<PI;
    return 0;
}
//my_list_1
//_Age_
//mynum!,@,#,&,%
//myint