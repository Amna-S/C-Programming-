/*#include <iostream>
int main()
{
    int x=30;
    int y=50;
    std::cout<<std::max(30,50);
    return 0;
}*/
/*#include <iostream>
#include <cmath>
int main()
{
    std::cout<<sqrt(64)<<"\n";
    std::cout<<log(3)<<"\n";
    std::cout<<round(3.78);
    return 0;
}*/
#include <iostream>
int main()
{
    int x=45;
    int y=55;
    if(y>x)
    {
        std::cout<<"y is greater than x";
    }
    return 0;
}


