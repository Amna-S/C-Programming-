//default parameter value:
#include <iostream>
#include <string>
/*void myfunction(std::string country="America")
{
    std::cout<<country<<"\n";
}
int main()
{
    myfunction("Sweden");
    myfunction("Finland");
    myfunction("Norway");
    myfunction();
    return 0;
}
void myfunction(std::string fname, int age)
{
    std::cout<<fname<<" Sarfraz "<<age<<" years old.\n";
}
int main()
{
    myfunction("Amna",12);
    myfunction("Hamza",10);
    myfunction("Abdullah",13);
    myfunction("Fatima",14);
    return 0;
}
int myfunction(int x,int y)
{
    return x+y;
}
int main()
{
    std::cout<<myfunction(6,8);
    return 0;
}
int myfunction(int x,int y)
{
    return x+y;
}
int main()
{
    int z=myfunction(4,9);
    std::cout<<z;
    return 0;
}*/
//Recursion:
int sum(int k)
{
    if(k>0)
    {
        return k +sum(k-1);
    }
    else
    {
        return 0;
    }
}
int main()
{
    int result=sum(10);
    std::cout<<result;
    return 0;
}




















