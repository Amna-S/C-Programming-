#include <iostream>
using namespace std;
int main()
{
       int mynum=45;
    // This is a code for you
    cout<<"Hello World \n";// this is a  comment
    cout<<"Pastas are divided into two broad categories: dried (pasta secca) and fresh (pasta fresca). Most dried pasta is produced commercially via an extrusion process, although it can be produced at home. Fresh pasta is traditionally produced by hand, sometimes with the aid of simple machines \n";
    cout<<mynum;
    return 0;
}
//types of variables
//integer(int)
//char (character, covered with single quotes)
//double(floating number)
//string(text, covered with double quotes)
//bool(True,False)
//variables they are containers used to store data values

















