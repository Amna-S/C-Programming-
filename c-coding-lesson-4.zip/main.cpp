#include <iostream>
int main()
{
    int x,y,z;
    int sub;
    int mul;
    double div;
    std::cout<<"Type your first number:";
    std::cin>>x;
    std::cout<<"Type your second number:";
    std::cin >>y;
    std::cout<<"Type your third number:";
    std::cin>>z;
    sub=x-y-z;
    std::cout<<"Your answer is:"<<sub<<"\n";
    mul=x*y*z;
    std::cout<<"Your answer is:"<<mul<<"\n";
    div=x/y/z;
    std::cout<<"Your answer is:"<<div<<"\n";
    return 0;
}
