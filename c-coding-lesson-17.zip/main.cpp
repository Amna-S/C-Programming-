#include <iostream>
#include <string>
int main()
{
    struct {
        int num;
        std::string letters;
    } mystructure;
    mystructure.num=100;
    mystructure.letters="I like coding.";
    std::cout<<mystructure.num<<"\n";
    std::cout<<mystructure.letters;
    return 0;
}
