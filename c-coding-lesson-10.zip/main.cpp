/*#include <iostream>
int main()
{
    int n;
    std::cout<<"Enter your age:";
    std::cin>>n;
    if(n >=18)
    {
        std::cout<<"Eligible for voting";
    }
    else
    {
        std::cout<<"Not eligible";
    }
    return 
}*/
